﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] veiculos  = new string[20];
            string busca;

            for (int i = 0; i < 20; i++)
            {
                Console.WriteLine("digite o nome dos veiculos");
                veiculos[i] = Console.ReadLine();
                Console.Clear();

            }

            for (int i = 0; i < 20; i++)
            {
                Console.WriteLine(i + veiculos[i]);
            }

            Console.WriteLine(" qual nome deseja procurar");
            busca = Console.ReadLine();

            for (int i = 0; i < 1; i++)
            {
                if (busca == veiculos[i])
                {
                    Console.WriteLine("voce encontrou o veiculo");
                }

                else 
                {
                    Console.WriteLine("nao ha esse veiculo aqui");
                }
            }

            Console.ReadKey();




        }
    }
}
